let btn = document.querySelector("#stbtn");
let audio = document.querySelector("#audioUi");
let load = document.querySelector("#load");
let hid = document.querySelector("#content");
let setting = document.querySelector("#setbtn");


btn.onclick = () => {
  hid.classList.add("hd");
  load.style.display = "flex";
  audio.play();
  setTimeout(() => {
    window.location.href = "/Mini-Projects/Tic-Tac-Toe/Game/game.html";
  }, 2500);
};

/*setting.onclick = () => {
  hid.classList.add("hd");
  load.style.display = "flex";
  audio.play();
  setTimeout(() => {
    window.location.href = "/Mini-Projects/Tic-Tac-Toe/Ui/settings/settings.html";
  }, 500);
};*/
