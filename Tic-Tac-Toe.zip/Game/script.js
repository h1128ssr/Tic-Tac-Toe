//  Connects to html
let btn = document.querySelectorAll(".boxex");
let reset = document.querySelector(".restbtn");
let newGame = document.querySelector("#Nbtn");
let mess = document.querySelector(".messageBox");
let para = document.querySelector("#winPlayer");
let turn = document.querySelector(".turn");
let audio = document.getElementById("audio");


// gets random turn
const turnRad = () => {
  const turnType = [true, false];
  const random = Math.floor(Math.random() * 2);
  return turnType[random];
};
let turnrand = turnRad();

//  turn
let turnO = turnrand;

// display turn
if (turnO){
  btn.innerText = "o";
  turn.innerText = "Turn - X";
  turnO = false;
} else {
  btn.innerText = "x";
  turn.innerText = "Turn - O";
  turnO = true;
}

//  Winning patterns
const winPatterns = [
  [0, 1, 2],
  [3, 4, 5],
  [6, 7, 8],
  [0, 3, 6],
  [1, 4, 7],
  [2, 5, 8],
  [0, 4, 8],
  [2, 4, 6]
];


//  New game button
const regame = () => {
  turnO = true;
  enablebox();
  mess.classList.add("hide");
  turn.classList.remove("hid");
};

//  Choose X or O turn
btn.forEach((box) => {
  box.addEventListener("click", () => {
    if (turnO) {
      box.innerText = "o";
      turn.innerText = "Turn - X";
      turnO = false;
    } else {
      box.innerText = "x";
      turn.innerText = "Turn - O";
      turnO = true;
    }
    box.disabled = true;

    checkwinner();
  });
});

//  Play tap sound effect when click on reset button 
reset.onclick = () => {
  audio.play();
};

// disable box after clicked
const disableBox = () => {
  for (let box of btn) {
    box.disabled = true;
  };
};

//  enable box after reset game or new game
const enablebox = () => {
  for (let box of btn) {
    box.disabled = false;
    box.innerText = "";
  };
};


//  Show Winner player message

let win = new Audio('/Mini-Projects/Tic-Tac-Toe/soundEffects/game-bonus-144751.mp3');
const showWinner = (winner) => {
  para.innerText = `${winner} is Winner`;
  mess.classList.remove("hide");
  turn.classList.add("hid");
  disableBox();
  win.play();
}

//  Show Draw message
let draw = new Audio('/Mini-Projects/Tic-Tac-Toe/soundEffects/marimba-lose-250960.mp3');
const showDraw = () => {
  para.innerText = "It's a Draw!";
  mess.classList.remove("hide");
  turn.classList.add("hid");
  disableBox();
  draw.play();
};

//  Check who is winner
const checkwinner = () => {
  let isDraw = true;
  for (let pat of winPatterns) {
    let pos1Val = btn[pat[0]].innerText;
    let pos2Val = btn[pat[1]].innerText;
    let pos3Val = btn[pat[2]].innerText;

    if (pos1Val != "" && pos2Val != "" && pos3Val != "") {
      if (pos1Val === pos2Val && pos2Val === pos3Val) {
        showWinner(pos1Val);
        return;
      }
    }
  }
  //  check draw
  btn.forEach((box) => {
    if (box.innerText === "") {
      isDraw = false;
    }
  });
  if (isDraw) {
    console.log("It's a draw!");
    showDraw();
  }
};

//  link reset or new game function to button
reset.addEventListener("click", regame);
newGame.addEventListener("click", regame);
newGame.onclick = () => {
  audio.play();
}
